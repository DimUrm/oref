<?php
/**
 * cycle_oref_alert.php
 */

chdir(dirname(__FILE__) . '/../');
include_once('./config.php');
include_once('./lib/loader.php');
include_once('./lib/threads.php');
set_time_limit(0);
$db = new mysql(DB_HOST, '', DB_USER, DB_PASSWORD, DB_NAME);
include_once('./load_settings.php');
include_once(DIR_MODULES . 'oref_alert/oref_alert.class.php');

// ─── ПРАВКА #3: Оставляем только системный лог DebMes ───────────────────────
function oaLog($msg, $level = 'INFO') {
    global $cfg; // Подтягиваем глобальный конфиг из цикла
    $debug = intval($cfg['DEBUG'] ?? 1);
    if ($debug || in_array($level, ['ERROR', 'FATAL', 'WARN'])) {
        DebMes("OrefAlert | {$msg}", 'oref_alert');
    }
}

register_shutdown_function(function() {
    $e = error_get_last();
    if ($e && in_array($e['type'],[E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        $msg = 'FATAL: ' . $e['message'] . ' in ' . $e['file'] . ':' . $e['line'];
        DebMes($msg, 'oref_alert_crash');
    }
});

$CYCLE   = str_replace('.php', '', basename(__FILE__));
$STARTED = time();
$MAX_RT  = 2 * 3600;

try {
    $oref = new oref_alert();
    // Читаем конфиг из JSON вместо getGlobal
    $cfg  = $oref->readLocalConfig();
} catch (Throwable $e) {
    setGlobal($CYCLE . 'Status', 'crashed_init');
    exit(1);
}

oaLog("=== СТАРТ pid=" . getmypid() . " PHP=" . PHP_VERSION . " ===");
setGlobal($CYCLE . 'Run', $STARTED, 1);
setGlobal($CYCLE . 'Status', 'running');

$watchdog     = time();
$iteration    = 0;
$errCount     = 0;
$lastHistoryUpdate = 0;

while (true) {
    $iteration++;

    if (time() - $watchdog >= 5) {
        setGlobal($CYCLE . 'Run', time(), 1);
        $watchdog = time();
        $cfg = $oref->readLocalConfig();  // Перечитываем JSON без перезапуска цикла
    }

    $cmd = getGlobal($CYCLE . 'Control');
    if ($cmd === 'stop' || $cmd === 'restart') { setGlobal($CYCLE . 'Control', ''); oaLog("CMD={$cmd} — выходим."); break; }
    if (time() - $STARTED > $MAX_RT) { oaLog("MAX_RUNTIME — выходим для перезапуска."); break; }
    if (!$cfg['ENABLED']) { if ($iteration % 60 === 1) oaLog("Модуль отключён."); sleep(10); continue; }

    $obj = $cfg['OBJ'];

    try {
        if ((time() - $lastHistoryUpdate) > $cfg['HIST_INT']) {
            $histData = oaFetchHistory($oref, $cfg);
            $myZones  = array_filter(array_map('trim', explode(',', $cfg['FILTER'])));

            $lastHistTS = intval(getGlobal($obj . '.LastHistoryItemTS') ?: 0);
            $maxTS      = $lastHistTS;

            $groups = [];
            foreach ($histData as $item) {
                if ($item['ts'] <= $lastHistTS) continue;
                if ($item['ts'] > $maxTS) $maxTS = $item['ts'];

                $key = $item['title'] . '_' . $item['cat'];
                if (!isset($groups[$key])) {
                    $groups[$key] = ['date'=>$item['date'], 'ts'=>$item['ts'], 'cat'=>$item['cat'], 'title'=>$item['title'], 'state'=>$item['state'], 'all_areas'=>[], 'my_areas'=>[]];
                }
                if ($item['ts'] < $groups[$key]['ts']) {
                    $groups[$key]['ts'] = $item['ts']; $groups[$key]['date'] = $item['date'];
                }
                $groups[$key]['all_areas'][] = $item['area'];
                if (!empty($myZones) && in_array($item['area'], $myZones)) {
                    $groups[$key]['my_areas'][] = $item['area'];
                }
            }

            if (!empty($groups)) {
                usort($groups, function($a, $b) { return $a['ts'] <=> $b['ts']; });
                foreach ($groups as $group) {
                    $oref->appendHistory(
                        $group['state'] === 'no_alert' ? 'end' : 'alert',
                        $group['cat'],
                        array_unique($group['all_areas']),
                        array_unique($group['my_areas']),
                        true,             
                        $group['date']     
                    );
                }
                setGlobal($obj . '.LastHistoryItemTS', $maxTS);
                oaLog("[#{$iteration}] История: +".count($groups)." новых групп (TS до ".date('H:i:s',$maxTS).")");
            }

            $myActive =[];
            foreach ($histData as $item) {
                if ($item['state'] === 'alert' && (!empty($myZones) ? in_array($item['area'], $myZones) : true)) {
                    $myActive[] = $item['area'];
                }
            }
            $histString = implode(', ', array_unique($myActive));
            setGlobal($obj . '.History', mb_substr($histString, 0, 250, 'UTF-8'));
            $lastHistoryUpdate = time();
        }

        $realtimeRaw = $oref->httpGet('https://www.oref.org.il/warningMessages/alert/Alerts.json', $cfg['PROXY']);

        $currentHash = md5($realtimeRaw ?: '');
        $lastHash    = getGlobal($obj . '.LastDataHash');
        $dataChanged = ($currentHash !== $lastHash);
        if ($dataChanged) setGlobal($obj . '.LastDataHash', $currentHash);

        setGlobal($obj . '.UpTime', date('Y-m-d H:i:s'));

        $alertFound = false;
        $foundData  =[];

        if ($realtimeRaw) {
            $json = json_decode($realtimeRaw, true);
            if (is_array($json) && !empty($json['data'])) {
                $rtCat = intval($json['cat'] ?? 1);
                $title = $json['title'] ?? '';
                $histCat = $oref->rtToHistCat($rtCat, $title);
                if ($histCat === null) continue;  
                $state   = $oref->histCatToState($histCat);

                if ($state !== null) {  
                    $filterWords = array_filter(array_map('trim', explode(',', $cfg['FILTER'])));
                    foreach ($json['data'] as $city) {
                        if (empty($filterWords)) {
                            $alertFound = true;
                            $foundData = ['histCat'=>$histCat, 'state'=>$state, 'city'=>$city, 'title'=>$title];
                            break;
                        }
                        foreach ($filterWords as $word) {
                            if ($word && mb_stripos($city, $word, 0, 'UTF-8') !== false) {
                                $alertFound = true;
                                $foundData =['histCat'=>$histCat, 'state'=>$state, 'city'=>$city, 'title'=>$title];
                                break 2;
                            }
                        }
                    }
                }
            }
        }

        if (!$alertFound && isset($histData)) {
            $filterWords = array_filter(array_map('trim', explode(',', $cfg['FILTER'])));
            foreach ($histData as $item) {
                if (!$item['isActive'] || $item['state'] !== 'alert') continue;
                $city = $item['area'];
                if (empty($filterWords) || in_array($city, $filterWords)) {
                    $alertFound = true;
                    $foundData = [
                        'histCat' => $item['cat'],
                        'state'   => $item['state'],
                        'city'    => $city,
                        'title'   => $item['title'],
                    ];
                    break;
                }
            }
        }

        if ($alertFound) {
            $hc      = $foundData['histCat'];
            $state   = $foundData['state'];
            $city    = $foundData['city'];
            $catSet  = $oref->getCatSettings($hc);

            $cityInfo = $oref->getCityInfo($city);
            $cityId   = $cityInfo ? $cityInfo['id']      : '';
            $cityRu   = $cityInfo ? $cityInfo['name_ru'] : $city;
            $zoneRu   = $cityInfo ? $cityInfo['zone_ru'] : '';
            $mapData  = $oref->getMapData($city);

            setGlobal($obj . '.Category',     $hc);
            setGlobal($obj . '.Img',          $catSet['img']);
            setGlobal($obj . '.Name',         $catSet['name']);
            setGlobal($obj . '.Instructions', $catSet['instr']);
            setGlobal($obj . '.City',         $city);         
            setGlobal($obj . '.CityRu',       $cityRu);       
            setGlobal($obj . '.ZoneRu',       $zoneRu);       
            setGlobal($obj . '.CityID',       $cityId);       
            setGlobal($obj . '.MapData',      $mapData ?: ''); 
            setGlobal($obj . '.ShelterTime',  $cityInfo ? $cityInfo['countdown'] : AreaData::getMigunTime($city));
            setGlobal($obj . '.MyActiveAreas', $city);

            if ($state === 'pre_alert') {
                setGlobal($obj . '.Status', 'No Alert');
                callMethod($obj . '.' . $cfg['TRIGGER']);
                oaRunCustomCode('pre_alert', $cfg, $obj, $city, $hc);

            } elseif ($state === 'no_alert') {
                setGlobal($obj . '.Status', 'No Alert');
                callMethod($obj . '.' . $cfg['TRIGGER']);
                oaRunCustomCode('clear', $cfg, $obj, $city, $hc);

            } else {
                $prevStatus = getGlobal($obj . '.Status');
                if ($prevStatus !== 'Alert') {
                    setGlobal($obj . '.Count',        intval(getGlobal($obj . '.Count')) + 1);
                    setGlobal($obj . '.LastAlarmTime', date('Y-m-d H:i:s'));
                    setGlobal($obj . '.LastAlertTS',   time());
                    $oref->appendHistory('alert', $hc, [$city], [$city]);
                    oaLog("[#{$iteration}] НОВАЯ ТРЕВОГА — вызываем " . $obj . '.' . $cfg['TRIGGER']);
                }
                setGlobal($obj . '.Status', 'Alert');
                callMethod($obj . '.' . $cfg['TRIGGER']);
                oaRunCustomCode('alert', $cfg, $obj, $city, $hc);
            }

        } else {
            $lastAlarmStr = getGlobal($obj . '.LastAlarmTime');
            $lastAlarmTS  = $lastAlarmStr ? strtotime($lastAlarmStr) : 0;
            $timePassed   = $lastAlarmTS ? (time() - $lastAlarmTS) : PHP_INT_MAX;

            if (getGlobal($obj . '.Status') === 'Alert') {
                $autoCloseMin = $cfg['AUTO_CLOSE_TIME'];
                if ($timePassed > ($autoCloseMin * 60)) {
                    oaLog("[#{$iteration}] Автоотбой через {$autoCloseMin} мин");
                    setGlobal($obj . '.Status', 'No Alert');
                    $oref->appendHistory('auto_clear', 0, [],[]);
                    callMethod($obj . '.' . $cfg['TRIGGER']);
                    oaRunCustomCode('clear', $cfg, $obj, '', 0);
                }
            }
            if ($timePassed > 3600 && getGlobal($obj . '.City') !== '') {
                setGlobal($obj . '.Category',      '');
                setGlobal($obj . '.Img',           '/modules/oref_alert/icons/default.png');
                setGlobal($obj . '.Name',          '');
                setGlobal($obj . '.Instructions',  'Оповещений нет');
                setGlobal($obj . '.City',          '');
                setGlobal($obj . '.CityID',        '');
                setGlobal($obj . '.ShelterTime',   0);
                setGlobal($obj . '.MyActiveAreas', '');
                setGlobal($obj . '.Last14Sounded', 0);
            }
        }

        $st = getGlobal($obj . '.Status');
        setGlobal($CYCLE . 'Status', "ok #{$iteration} " . date('H:i:s') . " {$st}");
        $errCount = 0;

    } catch (Throwable $e) {
        $errCount++;
        oaLog("[#{$iteration}] ИСКЛЮЧЕНИЕ: " . $e->getMessage() . " @ " . $e->getFile() . ":" . $e->getLine(), 'ERROR');
        setGlobal($CYCLE . 'Status', "error: " . $e->getMessage());
        if ($errCount >= 10) { oaLog("10 ошибок — выход.", 'FATAL'); break; }
        sleep(8);
        continue;
    }

    $currentStatus = getGlobal($obj . '.Status');
    if ($currentStatus === 'Alert') {
        sleep(2);        
    } elseif ($dataChanged) {
        sleep(2);       
    } else {
        sleep(max(2, $cfg['POLL']));  
    }
}

setGlobal($CYCLE . 'Status', 'stopped');

function oaFetchHistory($oref, $cfg)
{
    $urls =[
        'https://www.oref.org.il/warningMessages/alert/History/AlertsHistory.json',
        'https://alerts-history.oref.org.il/Shared/Ajax/GetAlarmsHistory.aspx?lang=he&mode=1',
    ];
    $alertWindow = 120;   
    $result      =[];
    $seen        =[];
    $now         = time();

    foreach ($urls as $url) {
        $raw = $oref->httpGet($url, $cfg['PROXY']);
        if (!$raw) continue;
        $data = json_decode($raw, true);
        if (!is_array($data)) continue;

        foreach ($data as $rec) {
            $area    = trim($rec['data'] ?? '');
            $cat     = intval($rec['category'] ?? 1);
            $dateStr = str_replace('T', ' ', $rec['alertDate'] ?? $rec['date'] ?? '');
            $ts      = $dateStr ? strtotime($dateStr) : 0;

            if (!$area || !$ts) continue;

            $state = $oref->histCatToState($cat);
            if ($state === null) continue;  

            $key = $area . '_' . $cat . '_' . substr($dateStr, 0, 16);
            if (!isset($seen[$key])) {
                $seen[$key] = true;
                $result[] =[
                    'area'     => $area,
                    'cat'      => $cat,
                    'title'    => trim($rec['title'] ?? ''),
                    'date'     => $dateStr,
                    'ts'       => $ts,
                    'state'    => $state,
                    'isActive' => ($now - $ts) <= $alertWindow,
                ];
            }
        }
    }
    return $result;
}

function oaRunCustomCode($event, $cfg, $obj, $city, $histCat)
{
    $codeMap = [
        'alert'     => $cfg['CODE_ALERT'] ?? '',
        'pre_alert' => $cfg['CODE_PRE_ALERT'] ?? '',
        'clear'     => $cfg['CODE_CLEAR'] ?? '',
        'drill'     => $cfg['CODE_DRILL'] ?? '',
    ];
    $code = trim($codeMap[$event] ?? '');
    if (!$code) return;
    oaLog("Выполняем custom code для event={$event}");
    try {
        eval($code);
    } catch (Throwable $e) {
        oaLog("Ошибка в custom code ({$event}): " . $e->getMessage(), 'ERROR');
    }
}
?>